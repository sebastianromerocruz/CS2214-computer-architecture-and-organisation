; Assemble and link like this:
;     nasm -f elf -gstabs greet.asm
;     ld -o greet -m elf_i386 greet.o
; Run like this:
;     ./greet
